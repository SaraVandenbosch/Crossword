package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Screen {
	private JFrame frame;
	
	public static void openScreen() {
		JFrame f = new JFrame("Crossword puzzle");
		f.setSize(500,500);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		JPanel p = new JPanel();

		p.setLayout(new BorderLayout());
		JLabel label1 = new JLabel("Label 1");
		p.add(label1, BorderLayout.LINE_START);
		JLabel label2 = new JLabel("Label 2");
		p.add(label2, BorderLayout.LINE_END);
		JLabel label3 = new JLabel("Label 3");
		p.add(label3, BorderLayout.PAGE_END);

		JButton button = new JButton("Button 1");
		button.addActionListener(new ActionListener() {

			public void actionPerformed (ActionEvent event){
				f.setVisible(false);
			}  // end of method

		} // end of anon. inner class

				); // end of addActionListener method

		p.add(button);
		f.getContentPane().add( p );
		f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		//f.pack();  // This is is removed when the setSize function is used
		f.setVisible(true);
		
	}
	
	public static void main(String[] args) {
		openScreen();
	}

}
