package Reader;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesReader {
	private static String filename;
	private static String solution;
	
	public static String getFilename() {return filename;}

	public static void setFilename(String filename) {PropertiesReader.filename = filename;}

	public static String getSolution() {return solution;}

	public static void setSolution(String solution) {PropertiesReader.solution = solution;}

	
	public static void readProperties() {
		Properties properties = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream("config.properties");
			properties.load(input);
			
			setFilename(properties.getProperty("filename"));
			setSolution(properties.getProperty("solution"));
		}	
		catch (IOException ex) {
	        ex.printStackTrace();
	    } finally {
	        if (input != null) {
	            try {input.close();}
	            catch (IOException e) {e.printStackTrace();}
	            }
	    }
	}
	
}

