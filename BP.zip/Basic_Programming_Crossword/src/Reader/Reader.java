package Reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Reader {
	private static int height;
	private static int width;
	private static String[] tiles;
	private static ArrayList<String> instructions = new ArrayList<String>();
	
	public static int getHeight() {return height;}
	
	private static void setHeight(int height) {Reader.height = height;}
	
	public static int getWidth() {return width;}
	
	private static void setWidth(int width) {Reader.width = width;}
	
	public static String[] getTiles() {return tiles;}
	
	private static void setTiles(String[] tiles) {Reader.tiles = tiles;}
	
	public static ArrayList<String> getInstructions() {return instructions;}
	
	public static void reader() {
		try {
			PropertiesReader.readProperties();
			BufferedReader in = new BufferedReader(new FileReader(PropertiesReader.getFilename()));
			Scanner scanner = new Scanner(in);
			
			String firstLine = scanner.nextLine();
			String[] splitterLine = firstLine.split(" ");
			setHeight(Integer.parseInt(splitterLine[0]));
			setWidth(Integer.parseInt(splitterLine[1]));
			
			String[] tiles = new String[getHeight()*getWidth()];
			
			for (int i = 0; i < (getHeight()*getWidth()); i++) {
				tiles[i] = scanner.next();
				setTiles(tiles);
			} 
			
			while (scanner.hasNext()) {
				String nextLine = scanner.nextLine();
				instructions.add(nextLine);
			}
			scanner.close();
			in.close();
			}
				
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
