package Squares;

import java.awt.Color;

public class SolutionSquare extends Square{
	private String character;
	private String solution;

	public SolutionSquare() {
		super(Color.GRAY);
	}

	public String getCharacter() {
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}
	
	public boolean isCorrect() {
		if(getCharacter().equals(getSolution())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public boolean isChangeable() {
		return true;
	}
	
	

}
