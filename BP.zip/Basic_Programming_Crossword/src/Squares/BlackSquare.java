package Squares;

import java.awt.Color;

public class BlackSquare extends Square{

	public BlackSquare() {
		super(Color.BLACK);
	}

	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public boolean isChangeable() {
		return false;
	}
	
	

}
