package Play;

import Squares.SolutionSquare;

public class Solution {
	
	public static boolean checkBoard(SolutionSquare[] solutionSquares, String solution) {
		boolean checked = true;
		
		for (int i = 0; i < solutionSquares.length; i++) {
			if (solutionSquares[i].isCorrect() == false) {
				checked = false;
				}
			}
		return checked;
		}
	
	public static void putInSolution(SolutionSquare[] solutionSquares, String solution) {
		if (solution.length() == solutionSquares.length){
			String[] letters = solution.split("");
			for (int i=0; i < solutionSquares.length; i++) {
				solutionSquares[i].setSolution(letters[i]);
			}
		}
		else {
			throw new IllegalArgumentException("The number of solution squares is not equal to the length of the solution. #of squares"+solutionSquares.length);
		}
	}

}
