package Play;

import Board.Board;
import Board.MakeBoard;
import Reader.PropertiesReader;
import Reader.Reader;

public class Game {
	
	public static void main(String[] args) {
		Reader.reader();
		MakeBoard.tilesToSquares(Reader.getTiles());
		//System.out.print(Reader.getTiles().length + System.lineSeparator());
		
		Board board = new Board(Reader.getHeight(), Reader.getWidth(), MakeBoard.getSquaresOnBord(), MakeBoard.getSolutionSquares());
		//System.out.print(MakeBoard.getSolutionSquares().length + System.lineSeparator());
		//System.out.print(board.getSolutionSquares().length);
		String solution = PropertiesReader.getSolution();
		
		//System.out.print(solution);
		Solution.putInSolution(board.getSolutionSquares(), solution);
		
		board.getSolutionSquares()[0].setCharacter("s");		
		board.getSolutionSquares()[1].setCharacter("o");
		board.getSolutionSquares()[2].setCharacter("u");
		board.getSolutionSquares()[3].setCharacter("t");
		board.getSolutionSquares()[4].setCharacter("h");
		board.getSolutionSquares()[5].setCharacter("p");
		board.getSolutionSquares()[6].setCharacter("a");
		board.getSolutionSquares()[7].setCharacter("r");
		board.getSolutionSquares()[8].setCharacter("k");
		
		
		//click square
		//click character
		
		
		if (Solution.checkBoard(board.getSolutionSquares(), solution) == true) {
			System.out.print("Congratulations");
		}
		else {
			System.out.print("There is a mistake");
		}
		
		
	}
}
