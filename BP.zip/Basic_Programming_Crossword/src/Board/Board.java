package Board;

import Squares.SolutionSquare;
import Squares.Square;

public class Board {
	private int height;
	private int width;
	Square[] squaresOnBord;
	SolutionSquare[] solutionSquares;
	
	public Board(int height, int width, Square[] squaresOnBord, SolutionSquare[] solutionSquares) {
		this.height = height;
		this.width = width;
		this.squaresOnBord = squaresOnBord;
		this.solutionSquares = solutionSquares;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	public Square[] getSquaresOnBord(){
		return squaresOnBord;
	}
	
	public SolutionSquare[] getSolutionSquares() {
		return solutionSquares;
	}
	
	
	

}
