package Board;

import java.util.ArrayList;
import java.util.List;
import Squares.BlackSquare;
import Squares.BlueSquare;
import Squares.GraySquare;
import Squares.SolutionSquare;
import Squares.Square;
import Squares.WhiteSquare;

public class MakeBoard {
	
	private static List<Square> squaresOnBord = new ArrayList<>();
	private static List<Square> solutionSquares = new ArrayList<>();
	
	public static Square[] getSquaresOnBord(){
		Square[] arraySquaresOnBord = new Square[squaresOnBord.size()];
		return squaresOnBord.toArray(arraySquaresOnBord);
	}
	
	public static void addSquareToBoard(Square square) {squaresOnBord.add(square);}
	
	public void removeSquareFromBoard(Square square) {squaresOnBord.remove(square);}
	
	public static SolutionSquare[] getSolutionSquares(){
		SolutionSquare[] arraySolutionSquares = new SolutionSquare[solutionSquares.size()];
		return solutionSquares.toArray(arraySolutionSquares);
	}
	
	public static void addSolutionSquare(Square square) {solutionSquares.add(square);}
	
	public void removeSolutionSquare(Square square) {solutionSquares.remove(square);}
	
	public static void tilesToSquares(String[] tiles) {
		for (int i = 0; i < tiles.length; i++) {
			if (tiles[i].equals("O")) {
				WhiteSquare square = new WhiteSquare();
				addSquareToBoard(square);
			}
			else if (tiles[i].equals("X")){
				BlackSquare square = new BlackSquare();
				addSquareToBoard(square);
			}
			else if (tiles[i].equals("S")){
				GraySquare graySquare = new GraySquare();
				addSquareToBoard(graySquare);
				SolutionSquare solutionSquare = new SolutionSquare();
				addSolutionSquare(solutionSquare);
			}
			else {
				String[] letters = tiles[i].split(""); //SOLUTION INTO SQUARE
				if (letters[0].equals("H")){ 
					String help = letters[2];
					BlueSquare square = new BlueSquare(help);
					addSquareToBoard(square);
					}
				}
			
			}
		}
	
	public static void main(String[] args) {
		String[] tiles = new String[4];
		tiles[0] = "S";
		tiles[1] = "S";
		tiles[2] = "S";
		tiles[3] = "S";
		
		tilesToSquares(tiles);
		
		System.out.print(solutionSquares.size() + System.lineSeparator());
		System.out.print(getSolutionSquares().length);

	}

}
